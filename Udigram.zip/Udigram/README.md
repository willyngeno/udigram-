# Web-Chat-App
A Responsive Web Chat App Using Php , MySql and JavaScript

## Prerequisites 
- XAMPP [Php Runtime Environment]
     - click [HERE](https://www.apachefriends.org/index.html) To Download XAMPP

## Setup
- install the xampp and go to the xampp folder and go to "C:\xampp\htdocs\" and make a new folder and paste this code
- after that launch xampp and start the MySql and Apache service 
- go to your [localhost](https://localhost) and go the the php admin page
- go to the database section
          - and create a new database like this
          - ![image](https://user-images.githubusercontent.com/81908197/150941153-f89acb66-d810-4f82-be49-57aaab2809c6.png)


<p align="center">Made with ❤️ By <a href="//github.com/LUTTAPI123">Luttapi</a></p><br>


<a href="https://ko-fi.com/luttapi"> <img align="left" src="https://cdn.ko-fi.com/cdn/kofi3.png?v=3" height="50" width="210" alt="luttapi" /></p>



